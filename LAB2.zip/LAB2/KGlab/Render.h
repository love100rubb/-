﻿void initRender();
void Render(double );